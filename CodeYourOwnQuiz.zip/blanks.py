# -*- coding: utf-8 -*-


question_blank = ["__A__", "__B__", "__C__", "__D__", "__E__"]

difficulty = {
"easy" : "music is an __A__ form and __B__ activity whose __C__ is sound __D__ in __E__.",
"medium" : "in __A__ mythology, the nine __B__ were the __C__ who inspired __D__, science, and the __E__.",
"hard" : "in the __A__, music __B__ typically means the __C__ expression of __D__ notes and __E__.",
}

words = {
"easy":["art","cultural","medium","organized","time"],
"medium":["greek","muses","goddesses","literature","arts"],
"hard":["2000s","notation","written","music","rhythms"],
}

# to choose the level of the quize
def quiz_level():
    '''
    here we defined the quiz_level to run the code
    '''
    level = raw_input("Choose the level of the questions, type the level that u want. choose from easy, medium and hard.")
    print level
    if level in ["easy","medium","hard"]:
        print difficulty[level]
    if level in "easy" or "medium" or "hard":
        return checking(difficulty, words)
    else:
        print "this is not valid input."
        quiz_level()




def replaces(answer, blank):
    # defined answer_thequestion that takes difficulty, wors, and question_blank as input and replace the planks to the words
    difficulty = difficulty["easy"].replace("__A__", "art").replace("__B__", "cultural").replace("__C__", "medium").replace("__D__", "organized").replace("__E__", "time")
    difficulty["medium"].replace("__A__","greek").replace("__B__","muses").replace("__C__","goddesses").replace("__D__","literature").replace("__E__","art")
    difficulty["hard"].replace("__A__","2000s").replace("__B__","notation").replace("__C__","written").replace("__D__","music").replace("__E__","rhythms")


    return replaces

def checking(difficulty, words):
# this function to check the answer if correct or not
    index=0
    while index < len(words):
        print "find the answer for blank" + str(question_blank[index])
        answer = raw_input("")
        if answer == words[level]:
            print "correct, good job!" + difficulty
            index +=1
        elif answer == words[index].upper():
            difficulty = replaces(answer, blank)
        elif answer == words[index].lower():
            difficulty = replaces(answer, blank)
        else:
            answer != words[index]
            print "wrong, try again" + difficulty
        if index == len (words):
            print "the end"

quiz_level()
