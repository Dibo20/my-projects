import webbrowser

class Movie():
    valid_ratings = ["G", "PG", "PG-13", "R"]
    """This class shows movie details"""
    def __init__(self, movie_tile, movie_storyline, poster_image, trailer_youtube):
        self.title = movie_tile
        self.storyline = movie_storyline
        self.poster_image_url = poster_image
        self.trailer_youtube_url = trailer_youtube
