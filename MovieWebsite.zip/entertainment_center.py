import fresh_tomatoes
import media

Split = media.Movie("split",
    "guy has evidenced 23 personalities to his trusted psychiatrist",
    "https://images-na.ssl-images-amazon.com/images/M/MV5BZTJiNGM2NjItNDRiYy00ZjY0LTgwNTItZDBmZGRlODQ4YThkL2ltYWdlXkEyXkFqcGdeQXVyMjY5ODI4NDk@._V1_SY1000_CR0,0,675,1000_AL_.jpg",
    "https://www.youtube.com/watch?v=84TouqfIsiI")

Mud = media.Movie("mud",
    "Two young boys encounter a fugitive and form a pact to help him evade the vigilantes that are on his trail and to reunite him with his true love.",
    "https://images-na.ssl-images-amazon.com/images/M/MV5BMTU2MzcyODgyNV5BMl5BanBnXkFtZTcwNTc4MDYwOQ@@._V1_SY1000_CR0,0,674,1000_AL_.jpg",
    "https://www.youtube.com/watch?v=2m9IFlz2iYo")

Focus = media.Movie("focus",
    "In the midst of veteran con man Nicky's latest scheme, a woman from his past - now an accomplished femme fatale - shows up and throws his plans for a loop.",
    "https://images-na.ssl-images-amazon.com/images/M/MV5BMTUwODg2OTA4OF5BMl5BanBnXkFtZTgwOTE5MTE4MzE@._V1_.jpg",
    "https://www.youtube.com/watch?v=MxCRgtdAuBo")

Dunkirk = media.Movie("dunkirk",
    "Allied soldiers from Belgium, the British Empire and France are surrounded by the German army and evacuated during a fierce battle in World War II",
    "https://images-na.ssl-images-amazon.com/images/M/MV5BN2YyZjQ0NTEtNzU5MS00NGZkLTg0MTEtYzJmMWY3MWRhZjM2XkEyXkFqcGdeQXVyMDA4NzMyOA@@._V1_SY1000_CR0,0,674,1000_AL_.jpg",
    "https://www.youtube.com/watch?v=F-eMt3SrfFU")

Baywatch = media.Movie("Baywatch",
    "Devoted lifeguard Mitch Buchannon butts heads with a brash new recruit, as they uncover a criminal plot that threatens the future of the bay.",
    "https://i.jeded.com/i/baywatch.86784.jpg",
    "https://www.youtube.com/watch?v=nZ5tqzw841s")

Snatched = media.Movie("snatched",
    "When her boyfriend dumps her before their exotic vacation, a young woman persuades her ultra-cautious mother to travel with her to paradise, with unexpected results",
    "https://images-na.ssl-images-amazon.com/images/M/MV5BZTI5NWY1YTQtODYxMi00M2VmLTgzNDQtMGM3NWU5YjViNDE5XkEyXkFqcGdeQXVyMTkxNjUyNQ@@._V1_SY1000_SX675_AL_.jpg",
    "https://www.youtube.com/watch?v=PsBWnst8f7w")
#Add all the movies to the list
movies = [Split, Mud, Focus, Dunkirk, Baywatch, Snatched]

# open movies
fresh_tomatoes.open_movies_page(movies)
print (media.Movie.valid_ratings)
